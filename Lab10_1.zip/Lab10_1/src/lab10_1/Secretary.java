/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_1;

/**
 *
 * @author KNCY
 */
public class Secretary extends Employee implements Evaluation {

    private int typingSpeed;
    private int[] score;

    public Secretary(String name, int salary, int[] score, int typingSpeed) {
        super(name, salary);
        this.score = new int[score.length];

        for (int i = 0; i < score.length; i++) {
            this.score[i] = score[i];
        }
        this.typingSpeed = typingSpeed;
    }

    public double evaluate() {
        double sumScore = 0;
        for(int i = 0 ; i<this.score.length ; i++){
            sumScore = sumScore+this.score[i];
        }
        return sumScore;
    }

    public char grade(double g) {
        if(g>=90){
            super.setSalary(18000);
            return 'P';
        }
        return 'F';
    }
}

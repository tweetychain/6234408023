/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab11_1;

import java.util.ArrayList;

/**
 *
 * @author KNCY
 */
public class MusicBox implements SimpleQueue {

    private ArrayList<String> mName = new ArrayList<String>();

    public MusicBox() {

    }

    public void enqueue(Object o) {
        String enq = (String) o;
        mName.add(enq);
        System.out.println(enq + " is added in queue");
    }

    public void dequeue() {
        if (mName.size() <= 0) {
            System.out.println("Soory, there is no music in the playlist.");
        } else {
            System.out.println("Now Playing " + mName.get(0));
            mName.remove(0);
        }

    }
}

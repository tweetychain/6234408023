/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab11_1;

import java.util.ArrayList;

/**
 *
 * @author KNCY
 */
public class SelfCheckOut implements SimpleQueue {

    private ArrayList<Product> pList = new ArrayList<Product>();
    private double totalAmt = 0;

    public void enqueue(Object o) {
        pList.add((Product) o);
        System.out.println(pList.get(pList.size() - 1).getName() + " is added in queue");
    }

    public void dequeue() {
        if (pList.size() <= 0) {
            System.out.println("Soory, there is no product in the queue");
        } else {
            totalAmt = totalAmt + pList.get(0).getPrice();
            pList.remove(0);

        }

    }

    public double getAmount() {
        return totalAmt;
    }
}

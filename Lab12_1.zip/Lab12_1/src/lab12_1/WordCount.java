/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 *
 * @author KNCY
 */
public class WordCount {

    public static void main(String[] args) throws FileNotFoundException {
        Scanner in = new Scanner(System.in);
        String fileName = "textFile.txt";
        PrintWriter out = new PrintWriter(fileName);
        boolean nextLoop = true;
        String inString;
        System.out.println("Enter your text : ");
        while (nextLoop) {
            inString = in.nextLine();
            if (inString.equalsIgnoreCase("quit")) {
                nextLoop = false;
            } else {
                out.println(inString);
            }

        }
        in.close();
        out.close();

        int cntLine = 0;
        int cntWord = 0;
        int cntChar = 0;

        File inputFile = new File(fileName);
        in = new Scanner(inputFile);
        while (in.hasNextLine()) {
            inString = in.nextLine();
            cntLine = cntLine + 1;
            cntChar = cntChar + inString.length();
            if(!inString.isEmpty()){
                String[]words = inString.split("\\s+");
                cntWord = cntWord+words.length;
            }
        }
        in.close();
        System.out.println("Total characters : "+cntChar);
        System.out.println("Total words : "+cntWord);
        System.out.println("Total lines : "+cntLine);
    }

}

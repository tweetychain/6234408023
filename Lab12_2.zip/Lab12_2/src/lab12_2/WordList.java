/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author KNCY
 */
public class WordList {

    
    public static void main(String[] args) {
        Scanner in = null;
        ArrayList<String> dictList = new ArrayList<String>();
        File inputFile = new File("wordlist.txt");
        try{
            in = new Scanner(inputFile);
            while(in.hasNextLine()){
                dictList.add(in.nextLine());
            }
        }catch(FileNotFoundException e){
            System.out.println(e);
        }
        finally{
            if(in!=null){
                in.close();
            }
        }
        
        System.out.print("Enter a sentence: ");
        in = new Scanner(System.in);
        String inString = in.nextLine();
        System.out.println("Words not contained: ");
        int cntNotFound = 0;
        if(!inString.isEmpty()){
            String[]words = inString.split("\\s+");
            for(int i =0;i<words.length;i++){
                if(dictList.indexOf(words[i])<0){
                    System.out.println(words[i]);
                    cntNotFound ++;
                }
            }
            if(cntNotFound<=0){
                System.out.println("N/A");
            }
        }
    }
    
}

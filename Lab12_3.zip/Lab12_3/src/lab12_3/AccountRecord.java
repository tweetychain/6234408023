/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_3;

/**
 *
 * @author KNCY
 */
public class AccountRecord {
    public static final int NAME_LENGTH = 30;
    private int acctNo;
    private String name;
    private double balance;
    private int transCnt = 0;     

    public AccountRecord(int acctNo, String name, double balance) {
        this.acctNo = acctNo;
        this.name = name;
        this.balance = balance;
        this.transCnt = 0;
    }

    public int getAcctNo() {
        return acctNo;
    }

    public String getName() {
        return name;
    }
    
    public String getPadName(){
        return String.format("%1$-"+NAME_LENGTH+"s",name);
    }

    public double getBalance() {
        return balance;
    }
    
    public void setBalance(double balance){
        this.balance = balance;
    }

    public int getTransCnt() {
        return transCnt;
    }
    
    public void setTransCnt(int transCnt){
        this.transCnt = transCnt;
    }
}

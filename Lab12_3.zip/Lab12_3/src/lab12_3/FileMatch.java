/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_3;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author KNCY
 */
public class FileMatch {

    public static void main(String[] args) {
        ArrayList<AccountRecord> ar = new ArrayList<AccountRecord>();
        ArrayList<TransactionRecord> tr = new ArrayList<TransactionRecord>();
        try(Scanner master = new Scanner(new File("master.txt"))){
            int acctNo;
            String name;
            double balance;
            while(master.hasNext()){
                acctNo = Integer.parseInt(master.next());
                name = master.next()+""+master.next();
                balance = Double.parseDouble(master.next());
                ar.add(new AccountRecord(acctNo,name,balance));
            }
        }catch(FileNotFoundException e){
            System.out.println(e);
        }
        try(Scanner transaction = new Scanner(new File("trans.txt"))){
            int acctNo;
            double transAmt;
            while(transaction.hasNext()){
                acctNo = Integer.parseInt(transaction.next());
                transAmt = Double.parseDouble(transaction.next());
                tr.add(new TransactionRecord(acctNo,transAmt));
            }
        }catch(FileNotFoundException e){
            System.out.println(e);
        }
        try(RandomAccessFile r = new RandomAccessFile("newMaster.dat","rw")){
            for(AccountRecord a : ar){
                if(tr.size()>0){
                  for(TransactionRecord t : tr){
                      if(t.getAcctNo()==a.getAcctNo()){
                          a.setBalance(a.getBalance()+t.getTransAmt());
                          a.setTransCnt(a.getTransCnt()+1);
                      }
                    }
                  r.writeInt(a.getAcctNo());
                  r.writeChars(a.getPadName());
                  r.writeDouble(a.getBalance());
                  r.writeInt(a.getTransCnt());
                }
            }
        }
        catch(IOException e){
            System.out.println(e);
        }
        try(RandomAccessFile r =new RandomAccessFile("newMaster.dat","r")){
            int totRec = 0;
            int acctNo;
            String name;
            double balance;
            int transCnt;
            int recCnt = 0;
            double totBal = 0;
            int noTrans = 0;
            r.seek(0);
            while(r.length()-r.getFilePointer()>0){
                acctNo = r.readInt();
                name = "";
                for(int i =1;i<=AccountRecord.NAME_LENGTH;i++){
                    name = name+r.readChar();
                }
                balance = r.readDouble();
                transCnt = r.readInt();
                recCnt++;
                totBal = totBal+balance;
                if(transCnt == 0){
                    noTrans++;
                }
            }
            System.out.println("Total Account Record : "+recCnt);
            System.out.println("Total balance : "+totBal);
            System.out.println("No transaction : "+noTrans+" accounts.");
        }
        catch(FileNotFoundException e){
            System.out.println(e);
        }
        catch(IOException e){
            System.out.println(e);
        }
    }

}

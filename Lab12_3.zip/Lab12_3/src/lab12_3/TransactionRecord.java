/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_3;

/**
 *
 * @author KNCY
 */
public class TransactionRecord {
    private int acctNo;
    private double transAmt;
    
    public TransactionRecord(int acctNo,double transAmt){
        this.acctNo = acctNo;
        this.transAmt = transAmt;
    }
    
    public int getAcctNo(){
        return acctNo;
    }
    public double getTransAmt(){
        return transAmt;
    }
    
    public void setAcctNo(int acctNo){
        this.acctNo = acctNo;
    }
    
    public void setTransAmt(double transAmt){
        this.transAmt = transAmt;
    }
    
}

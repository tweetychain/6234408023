/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_1;

/**
 *
 * @author usci
 */
import java.awt.Rectangle;
import java.util.Random;
public class Lab2_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Random generator = new Random();
       int x1 = generator.nextInt(50)+1;
       int y1 = generator.nextInt(50)+1;
       int width1 = generator.nextInt(50)+1;
       int height1 = generator.nextInt(50)+1;
       int x2 = generator.nextInt(50)+1;
       int y2 = generator.nextInt(50)+1;
       int width2 = generator.nextInt(50)+1;
       int height2 = generator.nextInt(50)+1;
       Rectangle r1 = new Rectangle (x1,y1,width1,height1);
       Rectangle r2 = new Rectangle (x2,y2,width2,height2);
       System.out.println(r1);
       System.out.println(r2);
       Rectangle r3 = r1.intersection(r2);
       boolean e = r3.isEmpty();
       System.out.print("Is the intersected rectangle empty?:");
       System.out.println(e);
               
        
    }
    
}

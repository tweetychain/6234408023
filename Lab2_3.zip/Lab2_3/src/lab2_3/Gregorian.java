/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_3;

/**
 *
 * @author KNCY
 */
import java.util.GregorianCalendar;
import java.util.Calendar;
public class Gregorian {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //GregorianCalendar cal = new GregorianCalendar(2019,Calendar.JANUARY,8);
        GregorianCalendar cal = new GregorianCalendar();
        //GregorianCalendar myBirthday = new GregorianCalendar(1990,Calendar.MARCH,12);
        GregorianCalendar myBirthday = new GregorianCalendar(2000,Calendar.JULY,14);
        cal.add(Calendar.DAY_OF_MONTH,100);
        int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
        int month = cal.get(Calendar.MONTH)+1;
        int year = cal.get(Calendar.YEAR);
        int weekday = cal.get(Calendar.DAY_OF_WEEK);
        System.out.println(weekday+" "+dayOfMonth+" "+month+" "+year);
        
        myBirthday.add(Calendar.DAY_OF_MONTH,10000);
        dayOfMonth = myBirthday.get(Calendar.DAY_OF_MONTH);
        month = myBirthday.get(Calendar.MONTH)+1;
        year = myBirthday.get(Calendar.YEAR);
        weekday = myBirthday.get(Calendar.DAY_OF_WEEK);
        System.out.println(weekday+" "+dayOfMonth+" "+month+" "+year);
    }
    
}

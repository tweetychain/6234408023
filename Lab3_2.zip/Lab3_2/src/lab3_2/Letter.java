/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_2;

/**
 *
 * @author usci
 */
public class Letter {
    
    private String nameSender;
    private String nameEarner;
    private String message="";
    
    public Letter(String from, String to){
        nameSender = from;
        nameEarner = to; 
    }
    
    public void addLine(String line){
        message = message+line+"\n";
    }
    
    public String getText(){
        String header = "Dear "+nameEarner+":\n\n";
        String body = message;
        String footer = "\n"+"Sincerely,\n\n"+nameSender;
        return header+body+footer;
       }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_3;

/**
 *
 * @author KNCY
 */
public class CashRegister {
    private double give=0;
    private double balance=0;
    private double tax;
    private double taxTotal=0;

    
    public CashRegister(){
        tax = 0.07;
    }
    
    public CashRegister(double amount){
        tax = amount/100.0;
    }
    

    public void recordPurchase(double amount) {
        balance = balance+amount;
    }

    public void recordTaxablePurchase(double amount) {
        taxTotal =taxTotal+(amount*tax);
        balance = balance+amount;
    }
    
    public void enterPayment (double amount){
        give = give+amount;
    }
    
    public double giveChange(){
        return (give - balance - taxTotal);
    }
   /* 
    public double getTotalTax(){
        return (taxTotal);
    }
    */
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_2;

/**
 *
 * @author KNCY
 */
public class DigitExtractor {

   private int readNumber; 
    
   public DigitExtractor (int anInteger){
       readNumber = anInteger ;
   }
  
   public int nextDigit(){
       int digit = readNumber%10 ;
       readNumber = readNumber/10;
       return digit ;
   }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_3;

/**
 *
 * @author KNCY
 */
public class TimeInterval {
    
    private int start;
    private int stop;
    private int resultStart;
    private int resultStop;
    
    public TimeInterval(int timeStart , int timeStop){
        
        start = timeStart;
        stop = timeStop;
        
        int hrStart = (start/100)*60;
        int minStart = (start%100);
        resultStart = hrStart+minStart;
        
        int hrStop = (stop/100)*60;
        int minStop = (stop%100);
        resultStop = hrStop+minStop;
    
    }
    
    public int getHours(){
       
       int resultHR = (resultStop-resultStart)/60;
       return resultHR;
        
    }
    
    public int getMinutes(){
       
       int resultMin = (resultStop-resultStart)%60;
       return resultMin;
       
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_3;

/**
 *
 * @author KNCY
 */
import java.util.Scanner;

public class TimeIntervalTester {
    
    public static void main(String[] args) {
        Scanner time = new Scanner (System.in);
        
        System.out.print("Enter start time: ");
        int timeStart = time.nextInt();
        
        System.out.print("Enter end time: ");
        int timeStop = time.nextInt();
        
        TimeInterval x = new TimeInterval(timeStart,timeStop);
        
        System.out.println(x.getHours()+" hours "+x.getMinutes()+" minutes");
        
        
        
    }
    
}

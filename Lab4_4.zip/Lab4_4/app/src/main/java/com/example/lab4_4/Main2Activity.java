package com.example.lab4_4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        final TextView textViewResult = (TextView) findViewById(R.id.textViewResult);
        Intent intent= getIntent();
        final String param_text = intent.getStringExtra("easterSunday");
        textViewResult.setText(param_text);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent upIntent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(upIntent);
        return true;
    }
}

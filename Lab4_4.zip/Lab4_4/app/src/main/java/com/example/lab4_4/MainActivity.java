package com.example.lab4_4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DateFormatSymbols;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText editYear = (EditText) findViewById(R.id.editYear);
        final Button buttonSend = (Button) findViewById(R.id.buttonSend);
        buttonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String myYear = editYear.getText().toString();

                String retEasterSunday = "";
                int y = Integer.parseInt(myYear);
                int a, b, c, d, e, g, h, j, k, m, n, p, r;

                a = y % 19;
                b = y / 100;
                c = y % 100;
                d = b / 4;
                e = b % 4;
                g = ((8 * b) + 13) / 25;
                h = ((19 * a) + b - d - g + 15) % 30;
                j = c / 4;
                k = c % 4;
                m = (a + (11 * h)) / 319;
                r = ((2 * e) + (2 * j) - k - h + m + 32) % 7;
                n = (h - m + r + 90) / 25;
                p = (h - m + r + n + 19) % 32;
                // retEasterSunday = Integer.toString(p) + "/" + Integer.toString(n);
                // Month month = Month.of(n);
                // retEasterSunday = month + " " + Integer.toString(p);
                String month;
                month = new DateFormatSymbols().getMonths()[n - 1];
                //retEasterSunday = month + " " + Integer.toString(p) + ", " + myYear;
                retEasterSunday = month + " " + Integer.toString(p) ;

                Intent destination = new Intent(MainActivity.this,Main2Activity.class);
                destination.putExtra("easterSunday",retEasterSunday);
                startActivity(destination);
            }
        });
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5_1;

/**
 *
 * @author KNCY
 */
enum Day {
    SUNDAY("Sunday"), MONDAY("Monday"), TUESDAY("Tuesday"), WEDNESDAY("Wednesday"),
    THURSDAY("Thursday"), FRIDAY("Friday"), SATURDAY("Saturday");

    private final String dayName;

    Day(String nameDay) {
        dayName = nameDay;
    }

    public String getDayName() {
        return dayName;
    }
}

public class Zeller {

    private int dayOfMonth;
    private int month;
    private int year;

    public Zeller(int dd, int mm, int yyyy) {
        dayOfMonth = dd;
        month = mm;
        year = yyyy;
    }

    public Day getDayOfWeek() {
        int h, q, m, j, k;
        Day d;
        q = dayOfMonth;
        switch (month) {
            case 1:
                m = 13;
                year = year - 1;
                break;
            case 2:
                m = 14;
                year = year - 1;
                break;
            default:
                m = month;
                break;

        }
        j = year / 100;
        k = year % 100;
        h = (q + (26 * (m + 1) / 10) + k + (k / 4) + (j / 4) + (5 * j)) % 7;
        switch (h) {
            case 0:
                d = Day.SATURDAY;
                break;
            case 1:
                d = Day.SUNDAY;
                break;
            case 2:
                d = Day.MONDAY;
                break;
            case 3:
                d = Day.TUESDAY;
                break;
            case 4:
                d = Day.WEDNESDAY;
                break;
            case 5:
                d = Day.THURSDAY;
                break;
            case 6:
                d = Day.FRIDAY;
                break;
            default:
                d = Day.SATURDAY;
                break;
        }
        return d;
    }
}

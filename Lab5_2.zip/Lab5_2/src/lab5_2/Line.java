/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5_2;

import java.awt.geom.Point2D;

/**
 *
 * @author KNCY
 */

public class Line {
    private double slope;
    private double yIntersect;
    private double xIntersect;
    
    public Line(double x1, double y1, double m){
        slope = m;
        if(slope!=0){
            xIntersect = (y1-slope*x1)/slope;
            yIntersect = (-1*slope*x1)+y1;
        }
        else{
            xIntersect = Double.NaN;
            yIntersect = y1;
        }
    }
    
    public Line(double x1, double y1, double x2, double y2){
        if(x1==x2){
            slope = Double.NaN;
            xIntersect = x1;
            yIntersect = Double.NaN;
        }
        else if(y1==y2){
            slope = 0;
            xIntersect = Double.NaN;
            yIntersect = y1;
        }
        else{
            slope = (y2-y1)/(x2-x1);
            yIntersect = (-1*slope*x1)+y1;
            xIntersect = (y1-slope*x1)/slope;
        }
    }
    public Line(double m, double b){
        slope = m;
        yIntersect = b;
        if(slope==0){
            xIntersect = Double.NaN;
        }
        else{
            xIntersect = yIntersect/(-1*slope);
        }
    }
    public Line(double a){
        slope = Double.NaN;
        xIntersect = a;
        yIntersect = Double.NaN;
    }
    
    public boolean isParallel(Line line2){
        boolean retTF;
        if(Double.isNaN(slope)&&Double.isNaN(line2.slope)){
            retTF = true;
        }
        else{
            retTF = (slope==line2.slope);
        }
        return(retTF);
    }
    public boolean isEquals(Line line2){
        boolean retTF;
        if(Double.isNaN(slope)&&Double.isNaN(line2.slope)&&(xIntersect==line2.xIntersect)){
            retTF = true;
        }
        else{
            retTF = (slope==line2.slope)&&(yIntersect==line2.yIntersect);
        }
        return(retTF);
    }
    public boolean isIntersect(Line line2){
        boolean retTF;
        if(Double.isNaN(slope)&&Double.isNaN(line2.slope)){
            retTF = false;
        }
        else{
            retTF = (slope!=line2.slope);
        }
        return(retTF);
    }
    public Point2D.Double getIntersectionPoint(Line line2){
        double pX,pY;
        
        if(Double.isNaN(slope)){
            pX=xIntersect;
        }
        else if(Double.isNaN(line2.slope)){
            pX=line2.xIntersect;
        }
        else{
            pX = (line2.yIntersect - yIntersect)/(slope-line2.slope);
        }
        if(slope==0){
            pY = yIntersect;
        }
        else if(line2.slope==0){
            pY=line2.yIntersect;
        }
        else{
            pY = (slope*pX)+yIntersect;
        }
    Point2D.Double intersectPoint = new Point2D.Double(pX,pY);
    return intersectPoint;
    }
}

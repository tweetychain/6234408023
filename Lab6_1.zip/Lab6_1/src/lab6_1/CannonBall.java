/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_1;

/**
 *
 * @author KNCY
 */
public class CannonBall {

    private double initV;
    private double simS;
    private double simT = 0.0;
    public static final double g = 9.81;

    public CannonBall(double v) {
        initV = v;

    }

    public void simulatedFlight() {
        double currentV = initV;
        int i = 0;
        do {
            i = i + 1;
            simT = simT + 0.01;
            simS = simS + (currentV * 0.01);
            currentV = currentV - (g * 0.01);
            if (i % 100 == 0) {
                System.out.printf("Distance on %d sec: %.3f%n", (i / 100), simS);
            }
        } while (currentV > 0);
        System.out.printf("Final distance: %.3f  Total time %.2f%n",simS,simT);
    }

    public double calculusFlight(double t) {
        double s;
        s = (-0.5 * g * t * t) + (initV * t);
        return s;
    }

    public double getSimulatedTime() {
        return simT;

    }

    public double getSimulatedDistance() {
        return simS;
    }

}

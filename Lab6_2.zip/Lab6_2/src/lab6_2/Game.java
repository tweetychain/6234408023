/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_2;

/**
 *
 * @author KNCY
 */
import java.util.Random;
import java.util.Scanner;


public class Game {

    int rpsUser;
    int rpsCom;
    int rpsDiff;
    int comPoint = 0;
    int userPoint = 0;
    int diffPoint;
    String rpsStringUser;
    String rpsStringCom;
    String strRPS;

    public void play() {
        Scanner sc = new Scanner(System.in);
        do {
            do {
                System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
                if (sc.hasNextInt()) {
                    rpsUser = sc.nextInt();
                } else {
                    strRPS = sc.nextLine();
                    rpsUser = -1;
                }
            } while (rpsUser != 0 && rpsUser != 1 && rpsUser != 2);

            Random rand = new Random();
            rpsCom = rand.nextInt(3);

            rpsDiff = rpsUser - rpsCom;

            if (rpsUser == 0) {
                rpsStringUser = "ROCK";
            } else if (rpsUser == 1) {
                rpsStringUser = "PAPER";
            } else {
                rpsStringUser = "SCISSORS";
            }

            if (rpsCom == 0) {
                rpsStringCom = "ROCK";
            } else if (rpsCom == 1) {
                rpsStringCom = "PAPER";
            } else {
                rpsStringCom = "SCISSORS";
            }

            System.out.println("You enter: " + rpsStringUser);
            System.out.println("Computer: " + rpsStringCom);
            if (rpsDiff == 0) {
                System.out.println("It's a tie.");
            } else if (rpsDiff == -1 || rpsDiff == 2) {
                System.out.println("You lose!");
                comPoint = comPoint + 1;
            } else {
                System.out.println("You win!");
                userPoint = userPoint + 1;
            }

            diffPoint = userPoint - comPoint;

        } while (diffPoint < 2 && diffPoint > -2);

        if (diffPoint >= 2) {
            System.out.println("\n-------------------------\n\nCongrats! You win.");
        } else if (diffPoint <= -2) {
            System.out.println("\n-------------------------\n\nToo bad! You lose.");
        }
        System.out.println("User Score: " + userPoint);
        System.out.println("Computer Score: " + comPoint);
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_2;

/**
 *
 * @author KNCY
 */
public class RockPaperScissorTester {
    
    public static void main(String[] args) {
        Game game = new Game();
        game.play();
    }
    
}

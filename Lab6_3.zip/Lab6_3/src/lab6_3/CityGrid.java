/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_3;

/**
 *
 * @author KNCY
 */
import java.util.Random;

public class CityGrid {

    private int xCoor;
    private int yCoor;
    private int gridSize;
 
    public CityGrid(int size) {

        gridSize = size;
        xCoor = gridSize / 2;
        yCoor = gridSize / 2;
    }

    public void walk() {
        int udlr;
        Random rand = new Random();
        
                udlr = rand.nextInt(4);
                switch (udlr) {
                    case 0:
                        yCoor = yCoor - 1;
                        break;
                    case 1:
                        yCoor = yCoor + 1;
                        break;
                    case 2:
                        xCoor = xCoor - 1;
                        break;
                    case 3:
                        xCoor = xCoor + 1;
                        break;
                }
                


    }

    public boolean isInCity() {
        return (xCoor <= gridSize && xCoor >= 0 && yCoor <= gridSize && yCoor >= 0);
    }

    public void reset() {
        xCoor = gridSize / 2;
        yCoor = gridSize / 2;
    }

}

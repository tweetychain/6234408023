/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_3;

/**
 *
 * @author KNCY
 */
public class CityGridTester {

    public static void main(String[] args) {
        int i, j;
        int totalStep = 0;
        int countStep = 0;
        int maxStep = 0;
        double avgStep;
        int totalRound = 10000;
        int oneRoundMaxStep = 1000;
        CityGrid cg = new CityGrid(10);
        for (i = 1; i <= totalRound; i++) {
            for (j = 1; j <= oneRoundMaxStep; j++) {
                cg.walk();
                if (!cg.isInCity()) {

                    break;
                }
            }
            countStep = j - 1;
            totalStep = totalStep + countStep;
            if (countStep > maxStep) {
                maxStep = countStep;
            }
            cg.reset();

        }
        avgStep = totalStep / totalRound;
        System.out.printf("Average number of steps that a person can take and is still in the city: : %.2f%n", avgStep);
        System.out.printf("Maximum number of steps that a person can take and is still in the city: : %d%n", maxStep);

    }

}

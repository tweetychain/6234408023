package com.example.guess;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        final TextView textViewFix = (TextView) findViewById(R.id.textViewFix);
        final TextView textViewLastGuess = (TextView) findViewById(R.id.textViewLastGuess);
        final TextView textViewHint = (TextView) findViewById(R.id.textViewHint);
        final EditText editTextGuessNumber = (EditText) findViewById(R.id.editTextGuessNumber);
        final Button buttonGuess = (Button) findViewById(R.id.buttonGuess);

        Random rand;
        rand = new Random();
        final int answer = rand.nextInt(99) + 1;


        buttonGuess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String guessNumberString = editTextGuessNumber.getText().toString();
                textViewLastGuess.setText(guessNumberString);
                int yourGuess = Integer.parseInt(guessNumberString);
                if(yourGuess > answer) {
                    textViewHint.setText("Your guess is too high");
                }
                else if(yourGuess < answer) {
                    textViewHint.setText("Your guess is too low");
                }
                else {
                    textViewHint.setText("Your guess is correct!");

                Intent destination = new Intent(Main2Activity.this, Main3Activity.class);
                //destination.putExtra("easterSunday",retEasterSunday);
                startActivity(destination);

                }
                editTextGuessNumber.setText("");
            }
        });
    }
}

package com.example.guess;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Main3Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        final TextView textViewYouWon = (TextView) findViewById(R.id.textViewYouWon);
        final Button buttonPlayAgain = (Button) findViewById(R.id.buttonPlayAgain);

        buttonPlayAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent destination = new Intent(Main3Activity.this, MainActivity.class);
                //destination.putExtra("easterSunday",retEasterSunday);
                startActivity(destination);
            }

        });
    }
}

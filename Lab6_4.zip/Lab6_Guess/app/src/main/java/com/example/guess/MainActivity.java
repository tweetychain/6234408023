package com.example.guess;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView textViewGuess = (TextView) findViewById(R.id.textViewGuess);
        final Button buttonSend = (Button) findViewById(R.id.buttonStart);

        buttonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent destination = new Intent(MainActivity.this, Main2Activity.class);
                //destination.putExtra("easterSunday",retEasterSunday);
                startActivity(destination);
            }
        });
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_1;

import java.util.ArrayList;

/**
 *
 * @author KNCY
 */
public class Purse {

    private ArrayList<String> myPurse = new ArrayList<String>();

    public void addCoin(String coinName) {
        myPurse.add(coinName);
    }

    public String toString() {
        return myPurse.toString();
    }

    public ArrayList<String> reverse() {
        ArrayList<String> myPurseRev = new ArrayList<String>();
        for (int i = myPurse.size() - 1; i >= 0; i--) {
            myPurseRev.add(myPurse.get(i));
        }
        myPurse.clear();
        for (int i = 0; i < myPurseRev.size(); i++) {
            myPurse.add(myPurseRev.get(i));
        }
        return myPurse;
    }

    public void transfer(Purse other) {
        for (int i = 0; i < myPurse.size(); i++) {
            other.addCoin(myPurse.get(i));
        }
        myPurse.clear();
    }

    public boolean sameContents(Purse other) {
        boolean retTF = true;
        if (myPurse.size() != other.myPurse.size()) {
            retTF = false;
        } else {
            for (int i = 0; i < myPurse.size(); i++) {
                if (myPurse.get(i) != other.myPurse.get(i)) {
                    retTF = false;
                    break;
                }
            }
        }
        return retTF;
    }

    public boolean sameCoin(Purse other) {
        boolean retTF = true;
        boolean found = true;
        ArrayList<String> myPurseR1 = new ArrayList<String>();
        ArrayList<String> myPurseR2 = new ArrayList<String>();
        if (myPurse.size() != other.myPurse.size()) {
            retTF = false;
        } else {
            for (int i = 0; i < myPurse.size(); i++) {
                myPurseR1.add(myPurse.get(i));
            }
            for (int i = 0; i < other.myPurse.size(); i++) {
                myPurseR2.add(other.myPurse.get(i));
            }
            for (int i = 0; i < myPurseR1.size(); i++) {
                found = false;
                for (int j = 0; j < myPurseR2.size(); j++) {
                    if (myPurseR1.get(i).equals(myPurseR2.get(j))) {
                        myPurseR2.remove(j);
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    retTF = false;
                    break;
                }
            }
        }
        return retTF;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_1;

/**
 *
 * @author KNCY
 */
public class PurseTester {
    
    public static void main(String[] args) {
        Purse myPurse1 = new Purse();
        myPurse1.addCoin("Quarter");
        myPurse1.addCoin("Dime");
        myPurse1.addCoin("Nickle");
        myPurse1.addCoin("Dime");
        System.out.println("myPurse1" + myPurse1.toString());
        System.out.println("Expected: [Quarter,Dime,Nickle,Dime]\n");
        System.out.println("myPurse1Reverse" + myPurse1.reverse().toString());
        System.out.println("Expected: [Dime,Nickle,Dime,Quarter]\n");
        Purse myPurseA = new Purse();
        Purse myPurseB = new Purse();
        
        myPurseA.addCoin("Quarter");
        myPurseA.addCoin("Dime");
        myPurseA.addCoin("Nickle");
        myPurseA.addCoin("Dime");
        
        myPurseB.addCoin("Dime");
        myPurseB.addCoin("Nickle");
        
        System.out.println("myPurseA" + myPurseA.toString());
        System.out.println("myPurseB" + myPurseB.toString());
        System.out.println("");
        myPurseA.transfer(myPurseB);
        System.out.println("myPurseAtransferOut" + myPurseA.toString());
        System.out.println("Expected: []\n");
        System.out.println("myPurseBtransferIn" + myPurseB.toString());
        System.out.println("Expected: [Dime,Nickle,Quarter,Dime,Nickle,Dime]\n");
        Purse myPurseC = new Purse();
        Purse myPurseD = new Purse();
        
        myPurseC.addCoin("Quarter");
        myPurseC.addCoin("Dime");
        myPurseC.addCoin("Nickle");
        myPurseC.addCoin("Dime");
        
        myPurseD.addCoin("Nickle");
        myPurseD.addCoin("Dime");
        myPurseD.addCoin("Dime");
        myPurseD.addCoin("Quarter");
        
        System.out.println("myPurseC" + myPurseC.toString());
        System.out.println("myPurseD" + myPurseD.toString());
        System.out.println("");
        
        System.out.println("Two purses have the same contents: " + myPurseC.sameContents(myPurseD));
        System.out.println("Expected: false\n");
        System.out.println("Two purses have the same coins: " + myPurseC.sameCoin(myPurseD));
        System.out.println("Expected: true\n");
    }
    
}

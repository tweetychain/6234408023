/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_2;

/**
 *
 * @author KNCY
 */
import java.util.Arrays;

public class MagicSquare {

    private int nSquare;
    private int[][] square;

    public MagicSquare(int n) {
        nSquare = n;
        square = new int[nSquare][nSquare];
        int maxI = nSquare - 1;
        int maxJ = nSquare - 1;
        int i = maxI;
        int j = maxJ / 2;
        square[i][j] = 1;
        int k;
        for (k = 2; k <= nSquare * nSquare; k++) {
            i = i + 1;
            j = j + 1;
            if (i > maxI) {
                i = 0;
            }
            if (j > maxJ) {
                j = 0;
            }
            if (square[i][j] > 0) {
                i = i - 2;
                j = j - 1;
                if (i < 0) {
                    i = maxI - 1;
                }
                if (j < 0) {
                    j = maxJ;
                }
            }

            square[i][j] = k;
        }

    }

    public String[] toString(int r) {
        String[] str = new String[r];

        for (int i = 0; i < nSquare; i++) {
            str[i] = "";
            for (int j = 0; j < nSquare; j++) {
                str[i] = str[i] + Integer.toString(square[i][j]) + "\t";

            }

        }
        return str;
    }

}

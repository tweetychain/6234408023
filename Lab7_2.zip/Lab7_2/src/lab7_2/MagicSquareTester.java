/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_2;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author KNCY
 */
public class MagicSquareTester {

    public static void main(String[] args) {

        int n;
        String inString;
        Scanner in = new Scanner(System.in);
        do {
            System.out.print("Enter a positive integer odd number: ");
            if (in.hasNextInt()) {
                n = in.nextInt();
            } else {
                inString = in.nextLine();
                n = 0;
            }
        } while (n % 2 == 0 || n < 0);

        MagicSquare mq = new MagicSquare(n);
        String[] str1 = new String[n];
        str1 = mq.toString(n);
        for (int i = 0; i < n; i++) {
            System.out.println(str1[i]);
        }
    }

}

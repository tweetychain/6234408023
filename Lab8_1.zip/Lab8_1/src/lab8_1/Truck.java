/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_1;

/**
 *
 * @author KNCY
 */
public class Truck extends Car {

    private double M_weight;
    private double weight;

    public Truck(double gas, double eff, double maxWeight, double w) {
        super(gas, eff);
        M_weight = maxWeight;
        if (w > M_weight) {
            weight = M_weight;
        } else {
            weight = w;
        }
    }

    public void drive(double distance) {
        double gasUse = distance / super.getEfficiency();
        if (weight > 20) {
            gasUse = gasUse + (gasUse * 30) / 100;
        }else if(weight > 10){
            gasUse = gasUse + (gasUse * 20) / 100;
        }else if(weight >= 1){
            gasUse = gasUse + (gasUse * 10) / 100;
        }
        if (gasUse > super.getGas()) {
            System.out.println("You cannot drive too far, please add gas");
        } else {
            super.setGas(super.getGas()-gasUse);
        }
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_2;

import java.util.ArrayList;

/**
 *
 * @author KNCY
 */

public class ChoiceQuestion extends Question{
    
    private ArrayList<String> choices =new ArrayList<String>();

    public ChoiceQuestion(String text){
        super(text);
    }
    
    public void addChoice(String choice, boolean correct){
        choices.add(choice);
        if(correct){
            super.setAnswer(choice);
        }
    }
    
    public void display(){
        System.out.println(super.getText());
        for(int i=1;i<=choices.size();i++){
            System.out.println(i+" "+choices.get(i-1));
        }
    }
    
    public boolean checkAnswer(String response){
        int resInt;
        try{
            resInt = Integer.parseInt(response);
        }catch(NumberFormatException nfe){
            return false;
        }
        if(resInt<=0||resInt>=choices.size()){
            return false;
        }
        return(choices.get(resInt-1).equalsIgnoreCase(super.getAns()));
    }
}

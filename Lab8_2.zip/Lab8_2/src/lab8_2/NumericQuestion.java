/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_2;

/**
 *
 * @author KNCY
 */
public class NumericQuestion extends Question {

    public NumericQuestion(String text) {
        super(text);
    }

    public boolean checkAnswer(String response) {
        double resD, ansD;
        try {
            resD = Double.parseDouble(response);
        } catch (NumberFormatException nfe) {
            return false;
        }
        ansD = Double.parseDouble(super.getAns());
        return (Math.abs(resD - ansD) <= 0.01);
    }
}

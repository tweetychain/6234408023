/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_1;

/**
 *
 * @author KNCY
 */
public class Customer {

    private String name, tel;

    public Customer(String name, String tel) {
        this.name = name;
        this.tel = tel;
    }
    
    public String getCustomerName(){
        return this.name;
    }

    public String getCustomerTel(){
        return this.tel;
    }
}

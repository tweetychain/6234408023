/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_1;

import java.util.ArrayList;

/**
 *
 * @author KNCY
 */
public class Order {

    public static int cntOrder = 0;
    private int id;
    private Customer c;
    private ArrayList<Pizza> p = new ArrayList<Pizza>();

    public Order(Customer c) {
        this.c = c;
        cntOrder++;
    }

    public void addPizza(Pizza p) {
        this.p.add(p);
    }

    public double calculatePayment() {
        double amount = 0;
        for (Pizza pi : p) {
            amount = amount + pi.getPizzaPrice();
        }
        if (c instanceof GoldCustomer) {
            GoldCustomer gc = (GoldCustomer) c;
            amount = amount - ((gc.getGoldCustomerDiscount()) * amount) / 100;
        }
        return amount;
    }

    public String getOrderDetail() {
        String s = "";
        s = "Order id : " + cntOrder + "\n" + c.getCustomerName() + " tel : " + c.getCustomerTel();

        if (c instanceof GoldCustomer) {
            GoldCustomer gc = (GoldCustomer) c;
            s = s + " discount : " + gc.getGoldCustomerDiscount();
        }

        for (Pizza pi : p) {
            s = s + "\n" + pi.getPizzaName() + " price : " + pi.getPizzaPrice();
            if (pi instanceof PizzaSpecial) {
                PizzaSpecial ps = (PizzaSpecial) pi;
                s = s + " special : " + ps.getPizzaSpecial();
            }
        }

        s = s + "\nTotal pieces : " + p.size();
        s = s + "\nToatal cost : " + calculatePayment();

        return s;
    }
}

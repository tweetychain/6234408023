/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_2;

/**
 *
 * @author KNCY
 */
public class Cosine extends Taylor {

    public Cosine(int k, double x) {
        super(k, x);
    }
    
    public void printValue(){
        System.out.println("Value from Math.cos() is "+Math.cos(super.getValue())+".");
        System.out.println("Approximate value is "+this.getApprox()+".");
    }
    
    public double getApprox(){
        int k = super.getIter();
        double x = super.getValue();
        double approxValue = 0;
        
        for(int n = 0 ; n<=k;n++){
            approxValue =approxValue+((Math.pow(-1,n))*(Math.pow(x,(2*n))))/super.factorial(2*n);
        }
        return approxValue;
    }

}
